#Stat159-fall2016-lab8
***

This repository contains the lab8 for the fall 2016, Statistics 159 at UC Berkeley.

This homework is about reproducing scatterplots sales versus different advertising channels(TV, Radio, Newspaper)

In this branch, there are 2 files: Advertising.csv, app.R.

1. app.R produce shinyDoc to see the scatterplots of sales versus different advertising channels.

2. Advertising.csv is the main data set downloaded from http://www-bcf.usc.edu/~gareth/ISL/Advertising.csv.

	(Credit to : Gareth James, Daniela Witten, Trevor Hastie and Robert Tibshirani) 

<a rel="license" href="http://creativecommons.org/licenses/by/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by/4.0/88x31.png" /></a><br />All media content (e.g. paper/report, and images) licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/4.0/">Creative Commons Attribution 4.0 International License</a>.

All code licensed under MIT License

Author: PhilHoon Oh

